export const QUOTE_FAILURE_RATE = 0.05; // 5% failure rate for quotes
export const PAYMENT_FAILURE_RATE = 0.1; // 10% failure rate for payments
export const STATUS_FAILURE_RATE = 0.02; // 2% failure rate for status checks