export const FEE_RATE = 0.01; // 1% fee rate
export const MINIMUM_FEE = 5; // Minimum fee in USD